#!/bin/bash
/var/www/back/.venv/bin/python /var/www/back/notifications/cron.py
