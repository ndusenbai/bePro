from django.apps import AppConfig


class BeproStatisticsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bepro_statistics'
