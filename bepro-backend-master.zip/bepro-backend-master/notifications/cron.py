import requests

url = 'https://bepro.kz/api/notification/check/'

resp = requests.get(url)
