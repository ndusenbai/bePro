from django.contrib import admin
from .models import AppVersion


admin.site.register(AppVersion)